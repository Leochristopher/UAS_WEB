<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
class CatController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */

 
    public function index()
    {
        
        $article = DB::table('articles')->join('categories','categories.id','=','articles.category_id')
       
        ->select('categories.name as category',
        'articles.description','articles.image',
        'articles.title','categories.id as id')



        ->get();


        return view('category', compact('article'));
  
    }
}
