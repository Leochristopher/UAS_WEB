<?php

namespace App\Http\Controllers;
use App\Blog;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
class BLController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */

 
    public function index()
    {
        
        $article = DB::table('articles')->join('categories','categories.id','=','articles.category_id')->join
        ('users','users.id','=','articles.user_id')
       
        ->select('categories.name as category',
        'articles.description','articles.image',
        'articles.title','categories.id as id','articles.user_id','articles.id as art_id')



        ->get();


        return view('bloglist', compact('article'));
  
    }
     // Delete
 public function destroy($id){


    $article=Blog::find($id);
    $article->delete();


    return redirect('/bloglist');
 }
}
