<?php

namespace App\Http\Controllers;
use Auth;
use App\Profile;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;


class ProfileController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */

 
    public function index()
    {
        
        $profile = DB::table('users')->get();



        return view('profile', compact('profile'));
  
    }
    
public function show($id)
{
    //
}



public function edit($id)
{$profile = profile::find($id);return view('profile',compact('profile'));;}

public function update(Request $request, $id)
{
    $user = Auth::user();
    $request->validate([
        'name' => ['string', 'max:255','required'],
        'email' => ['string', 'email', 'max:255'],
        'phone' => ['required']
        
    ]);
    $profile=Profile::find($id);
    $profile->name = $request->input('name');
    $profile->email = $request->input('email');
    $profile->phone = $request->input('phone');
    
    $profile->id= $user->id;
    $profile->password= $user->password;
    $profile->role= $user->role;

    $profile->save();
    return redirect('/homepage');
}

public function destroy($id){


    $profile=Profile::find($id);
    $profile->delete();


    return redirect('/user');
 }

}

