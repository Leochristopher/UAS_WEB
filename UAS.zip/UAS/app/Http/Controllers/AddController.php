<?php

namespace App\Http\Controllers;
Use App\Blog;
use Illuminate\Http\Request;
use Auth;

class AddController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function create(){return view('add');}

     

        public function store(Request $request)
    {
        $user = Auth::user();
        $request->validate([
      
            'category_id'=>'required',
            'title'=> 'required|max:255',
            'image'=> 'required',
            'description'=> 'required',
            ]);
        $articles = new Blog();
   
            $articles->user_id= $user->id;
            $articles->category_id=$request->input('category_id');
            $articles->title=$request->input('title');
            $articles->description=$request->input('description');
            $articles->image=$request->input('image');

                if($request->hasFile('image')){
                    $file = $request->file('image');
                    $extension = $file->getClientOriginalExtension();
                    $filename = '/img/'.time() . '.' . $extension;
                    $file->move('img/',$filename);
                    $articles->image = $filename;
                }
                
        $articles->save();
        return redirect('/bloglist');}

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        return view('add');
    }
}
