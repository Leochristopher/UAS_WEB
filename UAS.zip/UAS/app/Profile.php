<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Profile extends Model
{
    protected $table = 'users';
    public $timestamps = false;
    protected $fillable =  ['id','name','email','phone','role','password'];
}