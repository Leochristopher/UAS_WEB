<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Blog extends Model
{
    protected $table = 'articles';
    public $timestamps = false;
    protected $fillable =  ['user_id','category_id','title','image','description','id'];
}