<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
Route::get('/homepage', 'HomepageController@index')->name('homepage');
Route::get('/add', 'AddController@index')->name('add');
Route::get('/story', 'StoryController@index')->name('story');
Route::get('/category', 'CatController@index')->name('category');
Route::get('/bloglist', 'BLController@index')->name('bloglist');
Route::get('/add', 'AddController@create');
Route::post('/add', 'AddController@store');

Route::get('/user', 'UserController@index')->name('user')->middleware('myMid','role:admin');

Route::get('/profile', 'ProfileController@index')->name('profile');

Route::get('/profile/{id}/edit',('ProfileController@edit'));
Route::patch('/profile/{id}',('ProfileController@update'));

Route::delete('/bloglist/{id}', 'BLController@destroy');
Route::delete('/profile/{id}', 'ProfileController@destroy')->middleware('myMid','role:admin');;