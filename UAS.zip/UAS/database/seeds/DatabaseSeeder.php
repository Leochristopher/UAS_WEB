<?php

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        // $this->call(UserSeeder::class);
        DB::table('users')->insert([
            'name' => 'Leo',
            'email' => 'leo.coo@binus.ac.id',
            'phone'=> 8888,
            'role' => 'admin',
           'password' => bcrypt('leo.coo@binus.ac.id')
            
        ]
    );

        DB::table('users')->insert([
            'name' => 'Leo Christopher Coo',
            'email' => 'leochristophercoo@binus.ac.id',
            'phone'=> 8888,
            'role' => 'user',
           'password' => bcrypt('leochristophercoo@binus.ac.id')
            
        ]);

        DB::table('users')->insert([
            'name' => 'Leo',
            'email' => 'leo@binus.ac.id',
            'phone'=> 8888,
            'role' => 'user',
           'password' => bcrypt('leo@binus.ac.id')
            
        ]
    );
    DB::table('users')->insert([
        'name' => 'Leo',
        'email' => 'leo@leo.com',
        'phone'=> 8888,
        'role' => 'user',
       'password' => bcrypt('leo@leo.com')
        
    ]
);
DB::table('users')->insert([
    'name' => 'Leo',
    'email' => 'leo@1.com',
    'phone'=> 8888,
    'role' => 'admin',
   'password' => bcrypt('leo@1.com')
    
]
);

        DB::table('categories')->insert(['name' => 'Beach',]);

        DB::table('categories')->insert(['name' =>'Mountain']);

        DB::table('categories')->insert(['name' => 'Forest',]);

        DB::table('articles')->insert(['user_id' =>'1','category_id' =>'3','title'=>'Hutan pinus Mangunan, Yogyakarta','image'=>'/img/hutan.jpg'
        ,'description'=>'Lorem ipsum dolor sit amet consectetur adipisicing elit. Veritatis beatae, ipsam reiciendis impedit architecto sapiente exercitationem recusandae debitis quod quae a amet repudiandae eligendi iste molestiae. Necessitatibus eos deleniti doloribus!'
        ]
        );
        DB::table('articles')->insert([
        'user_id' =>'1','category_id' =>'1','title'=>'Pantai Tanah Lot ,Bali','image'=>'/img/pantai.jpg',
        'description'=>'Lorem ipsum dolor sit amet consectetur adipisicing elit. Facere minima odio, eaque non numquam eligendi rem praesentium! Quidem, recusandae magnam iste tempore provident vero odio obcaecati animi, debitis omnis nobis.'
        ]
        );

        DB::table('articles')->insert([
            'user_id' =>'4','category_id' =>'1','title'=>'Pantai 1, Bottom','image'=>'/img/beach.jpg',
            'description'=>'Lorem ipsum dolor sit amet consectetur adipisicing elit. Facere minima odio, eaque non numquam eligendi rem praesentium! Quidem, recusandae magnam iste tempore provident vero odio obcaecati animi, debitis omnis nobis.'
            ]
            );
            DB::table('articles')->insert([
                'user_id' =>'1','category_id' =>'2','title'=>'Gunung Tengkorak , Icecrown','image'=>'/img/m3.jpg',
                'description'=>'Lorem ipsum dolor sit amet consectetur adipisicing elit. Facere minima odio, eaque non numquam eligendi rem praesentium! Quidem, recusandae magnam iste tempore provident vero odio obcaecati animi, debitis omnis nobis.'
                ]
                );
            DB::table('articles')->insert([
                'user_id' =>'4','category_id' =>'2','title'=>'Gunung Lumut , Moss','image'=>'/img/m2.jpg',
                'description'=>'Lorem ipsum dolor sit amet consectetur adipisicing elit. Facere minima odio, eaque non numquam eligendi rem praesentium! Quidem, recusandae magnam iste tempore provident vero odio obcaecati animi, debitis omnis nobis.'
                 ]
                );
                DB::table('articles')->insert([
                    'user_id' =>'4','category_id' =>'2','title'=>'Gunung Air , Water','image'=>'/img/m1.jpg',
                    'description'=>'Lorem ipsum dolor sit amet consectetur adipisicing elit. Facere minima odio, eaque non numquam eligendi rem praesentium! Quidem, recusandae magnam iste tempore provident vero odio obcaecati animi, debitis omnis nobis.'
                     ]
                    );
    }
}
