

<?php $__env->startSection('content'); ?>
    

<h1 align="center">New Blog</h1>
<div class="container">
    <?php if($errors->any()): ?> 
    <div class="alert alert-danger">
    <ul>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    </div>
<?php endif; ?>
    <form action="<?php echo e(url('/add')); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>

        <div class="form-group">
            <label>title :</label>
            <input type="text" name = "title" class = "form-control" >
        </div>
        
        <div class="form-group">
            <label>Story :</label>
            <input type="text" name="description"  class = "form-control" >
        </div>

      
<input type="radio"   name="category_id"  value="1"  >Beach</label>
<input type="radio"   name="category_id"  value="2"  >Mountain</label>
<input type="radio"   name="category_id"  value="3"  >Jungle</label>
        

        <div class="input-group">
            <div class="custom-file">
                <label>Image : &emsp13;</label>
  
                
                <input type="file" id="myFile" name="image">
            </div>
            
        </div>
        <br>
        <button type="submit" name="submit" class="btn btn-primary">create</button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ASUS\Desktop\A\UAS\resources\views/add.blade.php ENDPATH**/ ?>