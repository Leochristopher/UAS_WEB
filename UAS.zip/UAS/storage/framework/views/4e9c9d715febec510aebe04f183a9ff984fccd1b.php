

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row-center">
        
            

            <div class="row">
                <?php $__currentLoopData = $article; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $articles): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                        <div class="col-md-3">
                            <ul style = 'list-style:none;'>
                                
                                    
                                    <li><h2><?php echo e($articles->title); ?></h2></li>
                                    <li><p><?php echo e($articles->description); ?></p><a href="/story?id=<?php echo e($loop->iteration); ?>">
                                        Full story </a></li>
                            <li>Category : <a href="/category?id=<?php echo e($articles->id); ?>"><?php echo e($articles->category); ?></a></li>
                                
                            </ul>
                        </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>     
                        
            </div>
    
            
   
</div>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ASUS\Desktop\A\UAS\resources\views/homepage.blade.php ENDPATH**/ ?>