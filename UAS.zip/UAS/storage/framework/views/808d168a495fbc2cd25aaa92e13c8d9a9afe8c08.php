

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row-center">
        <a href="/add"><button class="btn btn-primary" type="submit" >Create Blog</button></a>
            
            <table style="width:100%">
                <tr>
                    <th>Title</th>
                    <th>Action</th>
                  </tr>
            <div class="row">
                <?php $__currentLoopData = $article; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $articles): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(Auth::user()->id == $articles->user_id): ?>
         
                    
                        
                    
                               

<tr><td><?php echo e($articles->title); ?></td>
   
<td><form action="<?php echo e(url('bloglist/'.$articles->art_id)); ?>" method = 'post'>
                    <?php echo method_field('delete'); ?>
                    <?php echo csrf_field(); ?>
                    <button  class="btn btn-danger">Delete</button>
                </form></td></tr>




  <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>     
                        
            </div>
            
        </table>
            
    
   
</div>
<?php $__env->stopSection(); ?>



<?php if(Auth::user()->role=='user'): ?>


<?php endif; ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ASUS\Desktop\A\UAS\resources\views/bloglist.blade.php ENDPATH**/ ?>