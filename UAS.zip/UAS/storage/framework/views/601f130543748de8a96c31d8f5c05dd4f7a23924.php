

<?php $__env->startSection('content'); ?>


<?php 
$id =$_GET['id']; 
?>


<div class="container">
    <div class="row-center">
        
        

        <div class="row">
            
            <?php $__currentLoopData = $article; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $articles): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($id == $articles->id): ?>
                    <div class="col-md-4">
                        <ul style = 'list-style:none;'>
    
                        <li><img src="<?php echo e($articles->image); ?>" alt="" width="200px" height="200px"></li>
                                
                        <li><h2><?php echo e($articles->title); ?></h2></li>
                        <li><?php echo e($articles->description); ?></li>
                        
                        </ul>
                    </div>
                    <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
        
        
            
        <br>

    </div>
    <button class="btn btn-primary" type="submit" onclick="history.go(-1);">Back</button>
   
</div>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ASUS\Desktop\A\UAS\resources\views/story.blade.php ENDPATH**/ ?>