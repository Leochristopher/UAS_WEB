

<?php $__env->startSection('content'); ?>
<div class="container">
    <form action="/profile/<?php echo e(Auth::user()->id); ?>" method="POST" enctype="multipart/form-data">
        <?php if($errors->any()): ?> 
        <div class="alert alert-danger">
        <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        </div>
    <?php endif; ?>
    <?php echo method_field('PATCH'); ?>
    <?php echo csrf_field(); ?>
        <div class="form-group">
            <label> Name :</label>
  
            <input value= "<?php echo e(Auth::user()->name); ?>" type="text" name = "name" class = "form-control" >
        </div>
        
        <div class="form-group">
            <label>email :</label>
            <input value= "<?php echo e(Auth::user()->email); ?>"  type="email" name="email"  class = "form-control" >
        </div>

        <div class="form-group">
            <label>Phone :</label>
            <input value= "<?php echo e(Auth::user()->phone); ?>"   type="number" name="phone" class = "form-control" >
        </div>

        <button type="submit" name="submit" class="btn btn-primary">Update Profile</button>
    </form>
</div>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ASUS\Desktop\A\UAS\resources\views/profile.blade.php ENDPATH**/ ?>