@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row-center">
   
            {{-- @if(Auth::user()->role=='user') --}}
            <table style="width:100%">
                <tr>
                    <th>User</th>
                    <th>Action</th>
                  </tr>
            <div class="row">
                @foreach ($article as $articles)
                   @if ($articles->role !='admin')
                       
                   <tr><td>{{ $articles->name}}</td>
                    <td><form action="{{ url('profile/'.$articles->id) }}" method = 'post'>
                        @method('delete')
                        @csrf
                        <button  class="btn btn-danger">Delete</button>
                    </form></td></tr>
                   @endif
                    
@endforeach     
                        
            </div>
            
        </table>

    
   
</div>
@endsection


