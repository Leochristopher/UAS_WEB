@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row-center">
        
            

            <div class="row">
                @foreach ($article as $articles)
                
                        <div class="col-md-3">
                            <ul style = 'list-style:none;'>
                                {{-- <a href="/?id={{$loop->iteration}}"> --}}
                                    {{-- <li><img src="{{$articles->image}}" alt="" width="200px" height="200px"></li> --}}
                                    <li><h2>{{ $articles->title}}</h2></li>
                                    <li><p>{{$articles->description}}</p><a href="/story?id={{$loop->iteration}}">
                                        Full story </a></li>
                            <li>Category : <a href="/category?id={{$articles->id}}">{{$articles->category}}</a></li>
                                {{-- </a> --}}
                            </ul>
                        </div>
            @endforeach     
                        
            </div>
    
            
   
</div>
@endsection



