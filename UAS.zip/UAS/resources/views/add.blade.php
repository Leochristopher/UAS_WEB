@extends('layouts.app')

@section('content')
    

<h1 align="center">New Blog</h1>
<div class="container">
    @if ($errors->any()) 
    <div class="alert alert-danger">
    <ul>
    @foreach($errors->all() as $error)
        <li>{{$error}}</li>
    @endforeach
    </ul>
    </div>
@endif
    <form action="{{url('/add')}}" method="POST" enctype="multipart/form-data">
    @csrf

        <div class="form-group">
            <label>title :</label>
            <input type="text" name = "title" class = "form-control" >
        </div>
        
        <div class="form-group">
            <label>Story :</label>
            <input type="text" name="description"  class = "form-control" >
        </div>

      
<input type="radio"   name="category_id"  value="1"  >Beach</label>
<input type="radio"   name="category_id"  value="2"  >Mountain</label>
<input type="radio"   name="category_id"  value="3"  >Jungle</label>
        

        <div class="input-group">
            <div class="custom-file">
                <label>Image : &emsp13;</label>
  
                
                <input type="file" id="myFile" name="image">
            </div>
            
        </div>
        <br>
        <button type="submit" name="submit" class="btn btn-primary">create</button>
    </form>
</div>
@endsection