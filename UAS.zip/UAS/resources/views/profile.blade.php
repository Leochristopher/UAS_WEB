@extends('layouts.app')

@section('content')
<div class="container">
    <form action="/profile/{{{Auth::user()->id}}}" method="POST" enctype="multipart/form-data">
        @if ($errors->any()) 
        <div class="alert alert-danger">
        <ul>
        @foreach($errors->all() as $error)
            <li>{{$error}}</li>
        @endforeach
        </ul>
        </div>
    @endif
    @method('PATCH')
    @csrf
        <div class="form-group">
            <label> Name :</label>
  
            <input value= "{{Auth::user()->name}}" type="text" name = "name" class = "form-control" >
        </div>
        
        <div class="form-group">
            <label>email :</label>
            <input value= "{{Auth::user()->email}}"  type="email" name="email"  class = "form-control" >
        </div>

        <div class="form-group">
            <label>Phone :</label>
            <input value= "{{Auth::user()->phone}}"   type="number" name="phone" class = "form-control" >
        </div>

        <button type="submit" name="submit" class="btn btn-primary">Update Profile</button>
    </form>
</div>

@endsection



