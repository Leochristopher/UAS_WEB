@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row-center">
        <a href="/add"><button class="btn btn-primary" type="submit" >Create Blog</button></a>
            {{-- @if(Auth::user()->role=='user') --}}
            <table style="width:100%">
                <tr>
                    <th>Title</th>
                    <th>Action</th>
                  </tr>
            <div class="row">
                @foreach ($article as $articles)
                    @if (Auth::user()->id == $articles->user_id)
         
                    
                        
                    
                               

<tr><td>{{ $articles->title}}</td>
   
<td><form action="{{ url('bloglist/'.$articles->art_id) }}" method = 'post'>
                    @method('delete')
                    @csrf
                    <button  class="btn btn-danger">Delete</button>
                </form></td></tr>




  @endif
@endforeach     
                        
            </div>
            
        </table>
            {{-- @endif --}}
    
   
</div>
@endsection



@if(Auth::user()->role=='user')


@endif


{{-- @if(Auth::user()->role=='member')
<li><a href="">View Cart</a></li>
<li><a href=""> View Transaction</a></li>
@endif --}}