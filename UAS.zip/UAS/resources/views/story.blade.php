@extends('layouts.app')

@section('content')


<?php 
$id =$_GET['id']; 
?>


<div class="container">
    <div class="row-center">
        
        {{-- @if(Auth::user()->role=='user') --}}

        <div class="row">
            
            @foreach ($article as $articles)
            @if ($id == $articles->id)
                    <div class="col-md-4">
                        <ul style = 'list-style:none;'>
    
                        <li><img src="{{$articles->image}}" alt="" width="200px" height="200px"></li>
                                
                        <li><h2>{{ $articles->title}}</h2></li>
                        <li>{{$articles->description}}</li>
                        
                        </ul>
                    </div>
                    @endif
        @endforeach    
        
        {{-- @endif --}}
            
        <br>

    </div>
    <button class="btn btn-primary" type="submit" onclick="history.go(-1);">Back</button>
   
</div>
@endsection



{{-- @if(Auth::user()->role=='member')
<li><a href="">View Cart</a></li>
<li><a href=""> View Transaction</a></li>
@endif --}}